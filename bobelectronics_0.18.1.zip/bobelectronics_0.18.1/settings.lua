data:extend(
{
  {
    type = "bool-setting",
    name = "bobmods-colorupdate",
    setting_type = "startup",
    default_value = true,
  },
}
)

