local require = function(name) return require("data/entities/"..name) end
--require("logistic_beacon/logistic_beacon")
