data:extend({
	{
    type = "custom-input",
    name = "bluebuild-autobuild",
    key_sequence = "SHIFT + B",
    consuming = "none"
  },{
    type = "custom-input",
    name = "bluebuild-autodemo",
    key_sequence = "SHIFT + N",
    consuming = "none"
  }
 })