# Noxys Waterfill

A Factorio modification that adds various placeable waters. Very configurable.

## Discord

Want to discuss this mod or talk to Noxy directly? You can just go to the discord!

[<img src="http://cyanox.nl/discord.png" align="middle" title="Discord Invite to Noxys Naughty Nook"  /> Invite to Noxys Naughty Nook](https://discord.gg/0bly1P1wIaTXv9W5)

## Companion mod

[Noxys Swimming](https://mods.factorio.com/mods/CobaltSky/Noxys_Swimming). With swimming, waterfill is not as cheaty or deadly as without it.

## Factorio mod portal

[Factorio mod portal page.](https://mods.factorio.com/mods/CobaltSky/Noxys_Waterfill)
