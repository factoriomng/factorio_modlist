return {
	recipe_difficulty = {
		easy = "Easy",
		normal = "Normal",
		hard = "Hard",
	},
}