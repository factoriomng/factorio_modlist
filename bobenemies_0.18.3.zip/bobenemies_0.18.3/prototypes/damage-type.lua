data:extend(
{
  {
    type = "damage-type",
    name = "bob-pierce"
  },
  {
    type = "damage-type",
    name = "plasma"
  },
}
)
