bobmods.lib.tech.prerequisite_cleanup()
